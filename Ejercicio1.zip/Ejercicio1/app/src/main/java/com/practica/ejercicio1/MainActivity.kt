package com.practica.ejercicio1

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    var limite = 0
    var resultado: TextView? = null
    var txt_limite: EditText? = null
    var aceptar: Button? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        txt_limite=findViewById(R.id.Limite)
        resultado = findViewById<TextView>(R.id.Mostrar)

    }
    fun aceptar(view: View?) {
        limite=txt_limite!!.text.toString().toInt()
        var a=0
        var mostrar=""
        for(i in 2 until limite+2){
            a=(i*2)-1
            mostrar+=a;
            mostrar+=","
        }
        resultado?.text=mostrar

    }
}